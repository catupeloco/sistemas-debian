//Tabs
pref('browser.fullscreen.autohide', false);					//Sempre mostrar barras de ferramentas! Não auto ocultar!

