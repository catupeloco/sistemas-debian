/* ***** BEGIN LICENSE BLOCK ******
 * Version: MPL 2.0 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 2.0 (the "License"); you may not use this file except in compliance with
 *  the License. You may obtain a copy of the License at * http://www.mozilla.org/MPL/
 *
 *  Software distributed under the License is distributed on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 *  for the specific language governing rights and limitations under the
 *  License.
 *
 *  The Original Code is mfull.
 *
 *  The Initial Developer of the Original Code is Silmar A. Marca.
 *  Portions created by the Initial Developer are Copyright (C) 2010
 *  the Initial Developer. All Rights Reserved.
 *
 *  Contributor(s): Translators - see install.rdf for updated list.
 *
 *  ***** END LICENSE BLOCK *****
 */
 "use strict";

//Components.utils.import("resource://gre/modules/AddonManager.jsm");
//Components.utils.import("resource:///modules/CustomizableUI.jsm");
//Components.utils.import("resource://gre/modules/Services.jsm");
//Services.prefs.QueryInterface(Components.interfaces.nsIPrefBranch);
// Components.utils['import']('resource://mfull/content/browser/m_browser.js');

var showOptions = {
	isinit: false,		//Verifica se servico ativo
	strings : null,
	mainWindow: window,
	init: function (thiswindow) {
		// dump("..............<" + thiswindow.arguments[0].inn.window + ">....<" + window.arguments[0].inn.window  + ">............");
		// dump(window.arguments[0].inn.window.mfull_aparencia.isinit);		
		// window.arguments[0].inn.window.mfull_dialogs.notify("mfull_quit.title", "mfull_quit.body");
		if (showOptions.isinit) return;
		if (thiswindow) thiswindow.sizeToContent(); 															//Opcional, mas ajusta tamanho ao conteudo!
		if (thiswindow) showOptions.mainWindow = thiswindow;													//Pega janela atual
		showOptions.initialvalidate();																			//Validar campos
		showOptions.isinit = true;
	},	
	initialvalidate: function () {
		showOptions.addEventListenerByTagName("checkbox", "CheckboxStateChange", showOptions.updateCheckBox);
		showOptions.addEventListenerByTagName("radio", "RadioStateChange", showOptions.updateRadio);
		showOptions.addEventListenerByTagName("textbox", "change", showOptions.updateTextBox);
		showOptions.strings = document.getElementById("mfull.string.options");
		//Exibir botao de Aceitar e de Desabilitar
		document.documentElement.getButton('accept').hidden = false;
		document.documentElement.getButton('accept').disabled = false;
		document.documentElement.getButton('cancel').hidden = false;
		document.documentElement.getButton('cancel').disabled = false;
		document.documentElement.getButton('extra1').hidden = false;
		document.documentElement.getButton('extra1').disabled = false;		
		//Exibir todas barras ou não
		if (mfull_addonmanager.myversionisup("39.0")) document.getElementById('showbotombars').disabled = ! document.getElementById('showallbars').value;
		document.getElementById('prefsfavbar').hidden = ! document.getElementById('showallbars').value;	
		document.getElementById('prefsaddressbar').hidden = ! document.getElementById('showallbars').value;
		document.getElementById('prefstabsbar').hidden = ! document.getElementById('showallbars').value;		
		document.getElementById('hideonetab').disabled = ! document.getElementById('showallbars').value;		
		return true;
	},
	
	destory: function (janela) {
		return true;
	},
	command: function (cmd,janela) { 
		janela = typeof janela !== 'undefined' ? janela : false;											//Valor default delay inicial
		if (window.arguments) { 
			window.arguments[0].out = cmd;														//Janela popup chamada fora das opcoes, apenas passa parametros
			if (janela) janela.close();
		} else {
			do {
			} while (! mfull_actions.validateOptions(cmd,janela));							//Janela popup chamada dentro das opcoes, valida agora!	
		}
	},
	updateCheckBox: function (e) {	
		if ( e.target ) {
			switch (e.target.id) {
				case "showallbars":
						if (mfull_addonmanager.myversionisup("39.0")) document.getElementById('showbotombars').disabled = ! e.target.checked;
						if (e.target.checked) {					//Reset default preferencias
							document.getElementById('showbotombars').value = false;
							document.getElementById('showbookmarks').value = true;
							// document.getElementById('hideonetab').value = false;								
						}
						document.getElementById('prefsfavbar').hidden = ! e.target.checked;					
						document.getElementById('prefsaddressbar').hidden = ! e.target.checked;
						document.getElementById('prefstabsbar').hidden = ! e.target.checked;	
					break;		
				default:
					break;
			}		
		}
		return true;
	},
	updateTextBox: function (e) {	
		if ( e.target ) {
			switch (e.target.id) {
				default: break;
			}		
		}
		return true;
	},
	updateRadio: function (e) {		
		if ( e.target ) {
			switch (e.target.parentNode.id) {
				default: break;
			}
		}
		return true;
	},
	//--- [INI] Thaks to the Original Code Coral IE Tab (MPL 1.1) and now in mfull 
	addEventListener: function(obj, type, listener) {
	   if (typeof(obj) == "string") obj = document.getElementById(obj);
	   if (obj) obj.addEventListener(type, listener, false);
	},
	removeEventListener: function(obj, type, listener) {
	   if (typeof(obj) == "string") obj = document.getElementById(obj);
	   if (obj) obj.removeEventListener(type, listener, false);
	},
	addEventListenerByTagName: function(tag, type, listener) {
	   var objs = document.getElementsByTagName(tag);
	   for (var i = 0; i < objs.length; i++) {
		  objs[i].addEventListener(type, listener, false);
	   }
	},
	removeEventListenerByTagName: function(tag, type, listener) {
	   var objs = document.getElementsByTagName(tag);
	   for (var i = 0; i < objs.length; i++) {
		  objs[i].removeEventListener(type, listener, false);
	   }
	}
	//--- [END] Thaks to the Original Code for In Coral IE Tab (MPL 1.1) and now in mfull 
};