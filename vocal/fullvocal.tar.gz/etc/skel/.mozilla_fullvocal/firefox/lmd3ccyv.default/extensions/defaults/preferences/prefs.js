pref('extensions.mfull.config.firstrun', true);				//Primeira vez que roda? 
pref('extensions.mfull.config.unconfigured', true);			//Forcar re-configuracao, exibindo menu de opcoes quando sair da tela cheia? 
pref('extensions.mfull.config.islatestoptions', false);		//mfull foi atualizado recentemente, devendo entrar na tela de opcoes ao sair da tela cheia? 
pref('extensions.mfull.show.showallbars', true);			//Exibir barras (todas)
pref('extensions.mfull.show.bottombars', false);			//Inverter barras para baixo
pref('extensions.mfull.show.tabs.single',false);			//Auto ocultar se somente uma tab
pref("extensions.mfull.startup.fullscreen", false);	   	 	//Iniciar sempre em tela cheia, independente do ultimo estado
pref("extensions.mfull.laststate.fullscreen", false);	   	//Ultimo estado da tela cheia. Por padrao, inicialmente como falso.
pref("extensions.mfull.show.bookmarks.toolbar", true);		//Exibir Barra de favoritos e consequentemente botao imprimir e reset
pref("extensions.mfull.show.sidebar",0);					//Exibir Sidebar lateral
pref('extensions.mfull.show.addressbar', true);				//Exibir barra de enderecos em full screen

//---------------------------------------------------------------------------
////pref('javascript.options.strict', true);
//pref('devtools.errorconsole.enabled', true);				
//pref('javascript.options.showInConsole', true);
//pref('devtools.debugger.log', true); 
//pref('devtools.chrome.enabled', true); 
//pref('devtools.webconsole.persistlog', true); 
//pref('extensions.logging.enabled', true); 
//pref('nglayout.debug.disable_xul_cache', true);
//pref('browser.dom.window.dump.enabled', true);
//pref('devtools.debugger.remote-enabled', false);
//pref('nglayout.debug.disable_xul_fastload', true);
//pref('dom.report_all_js_exceptions', true);
//pref('devtools.errorconsole.deprecation_warnings', true);
