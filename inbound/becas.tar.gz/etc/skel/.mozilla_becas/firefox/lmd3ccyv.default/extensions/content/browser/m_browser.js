/* ***** BEGIN LICENSE BLOCK ******
 * Version: MPL 2.0 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 2.0 (the "License"); you may not use this file except in compliance with
 *  the License. You may obtain a copy of the License at * http://www.mozilla.org/MPL/
 *
 *  Software distributed under the License is distributed on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License 
 *  for the specific language governing rights and limitations under the
 *  License.
 *
 *  The Original Code is mKiosk, portable to mFull.
 *
 *  The Initial Developer of the Original Code is Silmar A. Marca.
 *  Portions created by the Initial Developer are Copyright (C) 2010
 *  the Initial Developer. All Rights Reserved.
 *
 *  Contributor(s): Translators - see install.rdf for updated list.
 *
 *  ***** END LICENSE BLOCK *****
 */
 /* Source code Mozilla: http://mxr.mozilla.org/mozilla-central/source/browser/base/content/ */
  "use strict";

//Biblioteca basica.. apenas definicoes
var mfull_lib = {
	isinit: false,		//Verifica se servico ativo
	strings : document.getElementById("mfull.string.browser"),																		//Strings com mensagens
	strprefmfull: "extensions.mfull.",																								//Pref mfull
	current_fullscreen: !window.fullScreen,																							//Fullscreen status. Seta ao contrario para verificar se � a primeira vez a ser ativado
	Services: Components.utils.import("resource://gre/modules/Services.jsm").Services, 												//Services
	AddonManager: Components.utils.import("resource://gre/modules/AddonManager.jsm").AddonManager, 									//AddonMagager
	PrefBranch   : Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch),			//Todas  Variaveis e preferencias
	MyPrefBranch : Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService).getBranch("extensions.mfull."), //mfull
	PromptService : Components.classes["@mozilla.org/embedcomp/prompt-service;1"].getService(Components.interfaces.nsIPromptService),  //Prompts Gerais - https://developer.mozilla.org/en/nsIPromptService
	AlertService : Components.classes["@mozilla.org/alerts-service;1"].getService(Components.interfaces.nsIAlertsService),			//Alertas
	WindowWatcher : Components.classes['@mozilla.org/embedcomp/window-watcher;1'].getService(Components.interfaces.nsIWindowWatcher),	//WindowWatcher
	VersionComparator : Components.classes["@mozilla.org/xpcom/version-comparator;1"].getService(Components.interfaces.nsIVersionComparator),  //Version compare
	mainWindow : Components.classes["@mozilla.org/appshell/window-mediator;1"].getService(Components.interfaces.nsIWindowMediator).getMostRecentWindow("navigator:browser"),	//Janela principal
	init: function() {
		if (mfull_lib.isinit) return; mfull_lib.isinit = true;
		//Pega a traducao com os strings
		mfull_lib.strings = mfull_lib.mainWindow.top.document.getElementById("mfull.string.browser");	
	}	
}

//Aparencias
var mfull_aparencia = {
	isinit: false,		//Verifica se servico ativo
	delayfullscreen:  1500,		//Tempo inicial para full screen
	//Algumas funcoes do proprio Browser, somente iniciadas apos o BrowserStartup
	//https://developer.mozilla.org/en-US/docs/Web/API/Window
	//Inicializa objetos (constuctor)
	startupapp: function() {
	  mfull_lib.init();														//Inicializar bibioteca principal e base
	  mfull_addonmanager.init();												//Inicializar desinstalador ou copia de configuracoes antigas
	  mfull_uteis.init();														//Iniciar utilitarios
	  mfull_dialogs.init();													//Caixas de dialogo
	  mfull_aparencia.init();													//Inicializar
	  mfull_actions.init();													//Acoes do browser
	  dump("\nmFull Addon Startup...\n");	
	},
	shutdown: function() {
	  dump("\nmFull Addon Shutdown...\n");	
	  mfull_lib.MyPrefBranch.setBoolPref('laststate.fullscreen',mfull_lib.current_fullscreen);	        //Salva ultimo estado do fullscreen
	},
	//Ao inicializar o browser
	init: function() {
		if (mfull_aparencia.isinit) return; mfull_aparencia.isinit = true;
		mfull_lib.init();														//Inicializar bibioteca principal e base
		//Inicializa o browser. Obrigatorio ser o primeiro
		BrowserStartup();		
		mfull_lib.mainWindow.top.gBrowser.setStripVisibilityTo(true);				  										 //Sempre ocultar inicialmente as Guias ao iniciar
		//Barra de Favoritos
		if (mfull_lib.mainWindow.top.document.getElementById("PersonalToolbar") instanceof XULElement) {					//Barra de Favoritos. A clausula fullscreentoolbar somente funciona ao reiniciar...
			mfull_lib.mainWindow.top.document.getElementById('PersonalToolbar').setAttribute('collapsed', false);   		//Exibir Favoritos padrao (Obrigatorio)
			mfull_lib.mainWindow.top.document.getElementById('PersonalToolbar').setAttribute('fullscreentoolbar', true); 	//Exibir em tela cheia. Ver atributos: autohide, collapsed e fullscreentoolbar 
		}
		//Barra de navega��o
		if (mfull_lib.mainWindow.top.document.getElementById("nav-bar") instanceof XULElement) {							//Barra de enderecos 
			mfull_lib.mainWindow.top.document.getElementById('nav-bar').setAttribute("collapsed", false);					//Exibir barra de navegacao padrao (Obrigatorio)
			mfull_lib.mainWindow.top.document.getElementById('nav-bar').setAttribute('fullscreentoolbar', true);		 	//Exibir em tela cheia. Ver atributos: autohide, collapsed e fullscreentoolbar
		}
		if (mfull_lib.mainWindow.top.document.getElementById("urlbar") instanceof XULElement) {							//Local de digita��o dos Enderecos, retirar tips e outros
			mfull_lib.mainWindow.top.document.getElementById('urlbar').setAttribute('emptytext',"");				
			mfull_lib.mainWindow.top.document.getElementById('urlbar').setAttribute('label',"");					
			mfull_lib.mainWindow.top.document.getElementById('urlbar').setAttribute('placeholder',"");				
		}
		//Barra de Menus (favoritos, ferramentas...)
		if (mfull_lib.mainWindow.top.document.getElementById("toolbar-menubar") instanceof XULElement) {					//Barra de Menus
			mfull_lib.mainWindow.top.document.getElementById('toolbar-menubar').setAttribute('collapsed', false);   		//Exibir menus, obrigatorio	
			mfull_lib.mainWindow.top.document.getElementById('toolbar-menubar').setAttribute('autohide', false);   			//Nao auto esconder
			mfull_lib.mainWindow.top.document.getElementById('toolbar-menubar').setAttribute('fullscreentoolbar', false);	//Exibir em tela cheia. Ver atributos: autohide, collapsed e fullscreentoolbar
		}		
		//if (mfull_lib.mainWindow.top.document.getElementById("minimize-button") instanceof XULElement) mfull_aparencia.mainWindow.document.getElementById("minimize-button").setAttribute('hidden', false); //Botoes fechar, minimizar, maximizar e restaurar do windows
		//if (mfull_lib.mainWindow.top.document.getElementById("close-button")    instanceof XULElement) mfull_aparencia.mainWindow.document.getElementById("close-button").setAttribute('hidden', false); 	//Botoes fechar, minimizar, maximizar e restaurar do windows
		//if (mfull_lib.mainWindow.top.document.getElementById("restore-button") instanceof XULElement) mfull_aparencia.mainWindow.document.getElementById("restore-button").setAttribute('hidden', true); 	//Botoes fechar, minimizar, maximizar e restaurar do windows
		
		//Ultimo status fullscreen. As vezes se for a primeira vez que ele roda, n�o h� status de lastfullscreen
		if (! mfull_lib.MyPrefBranch.getPrefType('laststate.fullscreen')) { mfull_lib.MyPrefBranch.setBoolPref('laststate.fullscreen',false); }    //Salva variavel fullscreen
		var tmplastrebootfullscreen = mfull_lib.MyPrefBranch.getBoolPref('laststate.fullscreen'); 	//[Backup]
		mfull_aparencia.fullscreen(false); 																		//Inicializar. Sempre bom iniciar em janela normal para maximizar depois!
		mfull_lib.MyPrefBranch.setBoolPref('laststate.fullscreen',tmplastrebootfullscreen); 		//[Restaurar]
		//Ve se realmente vai para fullscreen, por outros valores ou nao
		if (mfull_lib.MyPrefBranch.getBoolPref('startup.fullscreen') || mfull_lib.MyPrefBranch.getBoolPref('laststate.fullscreen')) {
			mfull_aparencia.updtprefs(true);																				//Atualizar preferencias, ocultando botoes rapidamente. O fullscreen somente atualiza se muda algo... cuidado!
			mfull_lib.mainWindow.top.setTimeout(function() { mfull_aparencia.fullscreen(true); }, mfull_aparencia.delayfullscreen);		//Ir para Janela cheia caso esteja bloqueado por senha
		} 
		//[Ini] Maximizar	
		mfull_lib.mainWindow.top.moveTo(0,0);																																								//Ajustes na janela
		mfull_lib.mainWindow.top.resizeTo(screen.availWidth, screen.availHeight);	
		//[Fim] Maximizar
		mfull_lib.mainWindow.top.setTimeout(function() { mfull_addonmanager.isFirstOrUpgrade(); }, 1000);   //Fistrun or upgrade code	
	},
    fullscreen: function(novo) {
		mfull_aparencia.init();													//Inicializar
		novo = typeof novo !== 'undefined' ? novo : ! mfull_lib.mainWindow.top.fullScreen;										//Valor default caso inexista como sendo o window.fullScreen
		mfull_lib.current_fullscreen = mfull_lib.mainWindow.top.fullScreen;													//Redundante, mas bom sempre atualizar...
		mfull_aparencia.updtprefs(novo);																					//Sempre antes de BrowserFullScreen!
		if (novo != mfull_lib.current_fullscreen) {	
			mfull_lib.current_fullscreen = !mfull_lib.mainWindow.top.fullScreen;	
			BrowserFullScreen(); 																							//Sempre depois de updtprefs!	
		}
		if (! novo) {
			mfull_lib.mainWindow.top.moveTo(0,0);																				//Ajustes na janela
			mfull_lib.mainWindow.top.resizeTo(screen.availWidth, screen.availHeight);											//Maximizar
			mfull_lib.mainWindow.top.maximize();
		}
		mfull_lib.MyPrefBranch.setBoolPref('laststate.fullscreen',mfull_lib.current_fullscreen);	        //Salva ultimo estado do fullscreen
    },	
    updtprefs: function (novo) {																							//Novo seria se eh em fullscreen ou nao	
		mfull_aparencia.init();													//Inicializar
		novo = typeof novo !== 'undefined' ? novo : mfull_lib.current_fullscreen;											//Valor default caso inexista como sendo o window.fullScreen
 		//Aplica apenas em fullscreen ou nao
		switch (mfull_lib.MyPrefBranch.getIntPref("show.sidebar")) {
			case 0: try { toggleSidebar(); } catch (e) { };	//Fechar sidebar. Cuidado bug. Por isto o try!	
				break;
			case 1: try { toggleSidebar(); } catch (e) { }; toggleSidebar("viewBookmarksSidebar", true);//Abre painel de favoritos ou SidebarUI.toggle('viewBookmarksSidebar',true)
				break;
			case 2: try { toggleSidebar(); } catch (e) { }; toggleSidebar("viewHistorySidebar", true);	 //Abre painel de historico ou SidebarUI.toggle('viewHistorySidebar',true)
				break;
			default:try { toggleSidebar(); } catch (e) { };
		}
		mfull_aparencia.showtabsornot(novo);																				//Exibir ou nao tabs de acordo com polices		
		// ZoomManager.setZoomForBrowser(getBrowser(),1); 																//Zoom		
		if (mfull_lib.mainWindow.top.document.getElementById("navigator-toolbox") instanceof XULElement) {	
			mfull_lib.mainWindow.top.document.getElementById('navigator-toolbox').setAttribute("hidden", false);		 	//Exibir Todas as barras caso ocultas
		}
		mfull_aparencia.copyconfigstowindow(mfull_lib.strprefmfull,"main-window",false);								//Copiar preferencias para objeto 
	},
	showtabsornot: function (novo) {
		mfull_aparencia.init();													//Inicializar
		novo = typeof novo !== 'undefined' ? novo : mfull_lib.current_fullscreen;		//Valor default caso inexista como sendo o window.fullScreen
		if (! novo) {														//Se nao estiver em tela cheia...
			mfull_lib.mainWindow.top.gBrowser.setStripVisibilityTo(true);			//Guias		
		} else if (mfull_lib.MyPrefBranch.getBoolPref('show.tabs.single')) {		//Ver opcao browser.tabs.autoHide
			mfull_lib.mainWindow.top.gBrowser.setStripVisibilityTo(mfull_lib.mainWindow.top.gBrowser.visibleTabs.length > 1);	//Firefox 5 ou superior. ID "tabbrowser-tabs"
		} else {
			mfull_lib.mainWindow.top.gBrowser.setStripVisibilityTo(true);			//Guias				
		}			
	},	
	//Limpa todas as preferencias. https://developer.mozilla.org/en-US/docs/Code_snippets/Preferences
	copyconfigstowindow : function (addonstr,classe,onlyhasmodify) {
		let prefTypes = {0: "", 32: "CharPref", 64: "IntPref", 128: "BoolPref"};				//Tipos 
		mfull_aparencia.init();													//Inicializar
 	    addonstr = typeof addonstr !== 'undefined' ? addonstr : mfull_lib.strprefmfull;					//"extensions.mfull." 
	    classe = typeof classe !== 'undefined' ? classe : "main-window";									//classe main window ou outra que seja
		if (! mfull_lib.mainWindow.top.document.getElementById(classe) instanceof XULElement) return false;	//Classe inexistente!	
	    onlyhasmodify = typeof onlyhasmodify !== 'undefined' ? onlyhasmodify : false;						//apenas os modificados pelo usu�rio ou n�o...
	    let Prefs = mfull_lib.PrefBranch.getBranch(addonstr);	
	    var arr = Prefs.getChildList("", {});
	    for (var prop in arr) {
			 var n_key = (addonstr + arr[prop]);															//Nome da preferencia completa
			 var c_key = "mfull_" + arr[prop].toLowerCase().replace(/\./gi,"_");;							//Nome futuro da classe igual ao nome da preferencia sempre iniciado por mfull_ adicionada pelo nome substituindo . por _	 .toLowerCase()?	
			 if ((!onlyhasmodify) || (arr.hasOwnProperty(prop))) { 											//Somente se modificado ou caso seja dito que deve ser todos!
					let prefType = prefTypes[mfull_lib.PrefBranch.getPrefType(n_key)];						//Pega tipo da preferencia:	CharPref, IntPref, BoolPref
					let v_key;
					try {
						v_key = mfull_lib.PrefBranch["get" + prefType](n_key);									//Pega valor (automatico mfull_lib.PrefBranch.get####Pref(n_key);)
						// if (prefType == "IntPref") v_key = parseInt(v_key);									//Converter para Inteiro
						v_key = v_key.toString();																//Converter para String 
					} catch (ex) {
						v_key = typeof v_key == "undefined" ? null : v_key;										//Nulo se erro
					}
					if (v_key) {																				//Se tiver algum valor
						switch (n_key) {
							case "extensions.mfull.show.bookmarks.toolbar":									//Exibir bookmarks
							case "extensions.mfull.show.addressbar":											//Barra de enderecos
							case "extensions.mfull.show.bottombars":											//Inverter barras para baixo	
							case "extensions.mfull.show.showallbars":											//Exibir ou ocultar geral, todas as barras e guia
							case "extensions.mfull.show.tabs.single":											//Exibir em tela cheia se apenas uma guia existir
								mfull_lib.mainWindow.top.document.getElementById(classe).setAttribute(c_key, v_key);			
							//	mfull_dialogs.notify(n_key + "->" + prefType + ":" + c_key + ":" + v_key);
								break;
							default:
								break;
						}			
					} else if (mfull_lib.mainWindow.top.document.getElementById(classe).hasAttribute(c_key)) {		//Se nao tiver valor algum, se tem o atributo, entao limpa!
						mfull_lib.mainWindow.top.document.getElementById(classe).removeAttribute(c_key);
					}
			 } 
	  }
	}
};

//Utilitarios
var mfull_uteis = {
	isinit: false,			//Verifica se servico ativo
	//Inicializador
	init: function () {
		if (mfull_uteis.isinit) return; mfull_uteis.isinit = true;
		mfull_lib.init();														//Inicializar bibioteca principal e base
	},
	RegexpTest : function (str,pattern) {
		mfull_uteis.init();													//Inicializar
		var strtest = new RegExp(pattern);                                          // "^\d{4}.\d{2}.\d{2}.\d{6}-\d{1}$"  'Tipo processos novos
	    return strtest.test(str);                                                   // "^\d{2}.\d{2}.\d{5}-\d{1}$"        'Numero estilo antigo 
	}
};

// https://developer.mozilla.org/en-US/docs/XPCOM_Interface_Reference/nsIPromptService?redirectlocale=en-US&redirectslug=nsIPromptService#confirm_example
var mfull_dialogs = {
	isinit: false,			//Verifica se servico ativo
	tmout_box: false,			//Timeout ativo
	//Inicializacao
	init: function () {
		if (mfull_dialogs.isinit) return; mfull_dialogs.isinit = true;
		mfull_lib.init();														//Inicializar bibioteca principal e base
	},
    notify : function(title, body, tipoicone) {
		mfull_dialogs.init();													//Caixas de dialogo
		title = typeof title !== 'undefined' ? title : 'mfull!';				//Titulo		
		if (typeof(body)  == 'undefined') { body = title; title = " mfull:"; }	//Valor default mensagens		
		tipoicone = typeof tipoicone !== 'undefined' ? tipoicone : '';		
		var iconemsg;
		switch (tipoicone) {
			case "full":
			default:
				iconemsg = "full"; break;
		}
		iconemsg = "chrome://mfull/content/images/" + iconemsg + ".png";
		var _title, _body, e;
		if (title.charAt(0) != " ") { try { _title = mfull_lib.strings.getString(title); } catch(e) { _title = title } } else { _title = title.substr(1); } 	//Ver getFormattedString
		if (body.charAt(0) != " ")  { try { _body  = mfull_lib.strings.getString(body); } catch(e)  { _body = body }	} else { _body = body.substr(1); }		//Ver getFormattedString
		if (! mfull_lib.current_fullscreen) {					//Agora a classe de alertas nao funciona mais em Full Screen!!!
			try {
				mfull_lib.AlertService.showAlertNotification(iconemsg, _title, _body, false, "", null);
			} catch(e) {
				// nao faz  nada se a notificacao nao ocorrer
			}	
		} else {
			try {
				var win = mfull_lib.WindowWatcher.openWindow(null, 'chrome://global/content/alerts/alert.xul','_blank', 'chrome,titlebar=no,popup=yes', null);  
				win.arguments = [iconemsg, _title, _body, false, ''];
			} catch(e) {
				// nao faz  nada se a notificacao nao ocorrer
			}	
		}
    },
	box : function(title, body, delay, delayini, statusfullscreen) {
		mfull_dialogs.init();													//Caixas de dialogo
		if (typeof(body)  == 'undefined') { body = title; title = " mfull:"; }								//Valor default mensagens
		delay = typeof delay !== 'undefined' ? delay : 0;													//Valor default delay ocultar
		delayini = typeof delayini !== 'undefined' ? delayini : 0;											//Valor default delay inicial
		//Somente em full screen ou nao
		if (typeof statusfullscreen !== 'undefined') {										
			mfull_lib.mainWindow.top.setTimeout(function() { if (mfull_lib.current_fullscreen == statusfullscreen) mfull_dialogs.box_ORI(title, body, delay); }, delayini);  
		} else {
			mfull_lib.mainWindow.top.setTimeout(function() { mfull_dialogs.box_ORI(title, body, delay); }, delayini);  		
		}
	},
	box_ORI : function(title, body, delay) {
		mfull_dialogs.init();													//Caixas de dialogo
		var _title, _body, e, xbox, nb, n;
		if (title.charAt(0) != " ") { try { _title = mfull_lib.strings.getString(title); } catch(e) { _title = title } } else { _title = title } 	//Ver getFormattedString
		if (body.charAt(0) != " ")  { try { _body  = mfull_lib.strings.getString(body); } catch(e)  { _body = body }	} else { _body = body }		//Ver getFormattedString
		//Cancela timeout anterior caso exista
		if (delay > 0) {
			if (mfull_dialogs.tmout_box) {
				mfull_lib.mainWindow.top.clearTimeout(mfull_dialogs.tmout_box);
				mfull_dialogs.tmout_box = false;
			}
		}
		try {
			nb = mfull_lib.mainWindow.top.gBrowser.getNotificationBox();
			n = nb.getNotificationWithValue('mfull_popupbox');
			if   (n) { 
				n.label = _title + ": " + _body; 
				if (delay > 0) { mfull_dialogs.tmout_box = mfull_lib.mainWindow.top.setTimeout(function() { nb.removeNotification(n); }, delay); }
			} else  { 
				xbox = nb.appendNotification(_title + ": " + _body, 'mfull_popupbox','chrome://browser/skin/info_48.png',nb.PRIORITY_WARNING_MEDIUM, null); 
				if (delay > 0) { mfull_dialogs.tmout_box = mfull_lib.mainWindow.top.setTimeout(function() { nb.removeNotification(xbox); }, delay); }					
			}	
		} catch(e) {	
			//Nao faz nada se der erro
		}
	},
	alert : function(title, body) {
		mfull_dialogs.init();													//Caixas de dialogo
		if (typeof(body)  == 'undefined') { body = title; title = " mfull:"; }
		var _title, _body, e;
		if (title.charAt(0) != " ") { try { _title = mfull_lib.strings.getString(title); } catch(e) { _title = title } } else { _title = title } 	//Ver getFormattedString
		if (body.charAt(0) != " ")  { try { _body  = mfull_lib.strings.getString(body); } catch(e)  { _body = body }	} else { _body = body }		//Ver getFormattedString
        try {
			mfull_lib.PromptService.alert(null, _title, _body);
        } catch(e) {
			mfull_lib.mainWindow.top.alert(_title + "\n" + _body); // se um erro ocorrer, notifica sem o titulo
        }
	}, 
	okcancel : function(title, body) {
		mfull_dialogs.init();													//Caixas de dialogo
		if (typeof(body)  == 'undefined') { body = title; title = " mfull:"; }
		var _title, _body, e;
		if (title.charAt(0) != " ") { try { _title = mfull_lib.strings.getString(title); } catch(e) { _title = title } } else { _title = title } 	//Ver getFormattedString
		if (body.charAt(0) != " ")  { try { _body  = mfull_lib.strings.getString(body); } catch(e)  { _body = body }	} else { _body = body }		//Ver getFormattedString

		var check = {value: false};                  				// hidden checkbox	
		var flags = ( mfull_lib.PromptService.BUTTON_POS_0 * mfull_lib.PromptService.BUTTON_TITLE_OK ) + 
					( mfull_lib.PromptService.BUTTON_POS_1 * mfull_lib.PromptService.BUTTON_TITLE_REVERT ) + mfull_lib.PromptService.BUTTON_DELAY_ENABLE;
		var button = mfull_lib.PromptService.confirmEx(null, _title, _body, flags, "", "", "", null, check);
		return button; 
	}, 
	showAbout: function() {	
		mfull_dialogs.init();													//Caixas de dialogo
		mfull_lib.AddonManager.getAddonByID(mfull_addonmanager.uid, function(addon) {
			mfull_lib.mainWindow.top.openDialog('chrome://mozapps/content/extensions/about.xul', '', 'chrome,centerscreen,modal,dialog,close=no', addon);
		});
	},
	//Parametros em https://developer.mozilla.org/en-US/docs/Web/API/window.open
	//Exemplos: resizable=off,scrollbars=off,menubar=off,toolbar=off,location=off,personalbar=off,status=off,titlebar=on
	showDialog: function(url,segundoplano,parmsadicionais) {
		mfull_dialogs.init();													//Caixas de dialogo
		segundoplano = typeof segundoplano !== 'undefined' ? segundoplano : true;				//ativa o segundo plano, permitindo manipular o browser em paralelo
		var e; var windowretorno = null;
		if (!url) url = 'chrome://mozapps/content/extensions/about.xul';
		var params = {inn:{window:window, url:url, segundoplano:segundoplano}, out:null};						//window.arguments[0].inn.atributo
		if (segundoplano != true) {
			windowretorno = mfull_lib.mainWindow.top.openDialog(url, '', 'chrome,centerscreen,modal,dialog,close=no', params, parmsadicionais);			//Ver variavel window.dialogArguments que ter� o conteudo de window. Retorno em window.returnValue
		} else {
			//Executar em segundo plano....
			mfull_lib.AddonManager.getAddonByID(mfull_addonmanager.uid, function(addonparam) {
				windowretorno = mfull_lib.mainWindow.top.openDialog(url, '', 'chrome,centerscreen,modal,dialog,close=no', params, parmsadicionais);		//Ver variavel window.dialogArguments que ter� o conteudo de window. Retorno em window.returnValue
			});
		}
		return windowretorno.arguments[0].out;
	}
}; 
//Acoes controladas pelo mfull
var mfull_actions = {
	isinit: false,			//Verifica se servico ativo
	print_last: 0, 			//Hora de Ultima Impressao
	print_count: 0,			//Numero de impressoes
	init: function () {
		if (mfull_actions.isinit) return; mfull_actions.isinit = true;
		mfull_lib.init();													//Inicializar bibioteca principal e base
	},
	//Vai preferencias do complemento
	showPreferences : function () {
		mfull_actions.init();													//Inicializar
		openPreferences();
		mfull_aparencia.updtprefs();													 							
	},
	//Vai para tela cheia ou sai dela, alternando
	fullscreen : function () {
		mfull_actions.init();																					//Inicializar		
		mfull_aparencia.fullscreen();																		//Efetuar switch do full screen
		mfull_addonmanager.isFirstOrUpgrade();																//Acoes de Upgrade?
		if (mfull_lib.current_fullscreen == true) {
			mfull_dialogs.box("mfull_help.f11.out.title", "mfull_help.f11.out.body",0, 250, true);   //Box com tempo definido, avisando que f11 sai da tela cheia
		} else {
			mfull_dialogs.box("mfull_help.f11.in.title", "mfull_help.f11.in.body",0, 2000, false);  //Box tempo indefinido avisando pra pressionar F11
		}
		return true;
	},
	//Restarta browser (copy pastle from UpdatePrompt.js, from mozilla)
	restart: function (type){
		type = typeof type !== 'undefined' ? type : true;	
		try { toggleSidebar(); } catch (e) { } 									//Sempre fechar sidebar. Cuidado com o bug, por isto o try!
		dump("\nmFull Addon Restart...\n");
		let appStartup = Components.classes["@mozilla.org/toolkit/app-startup;1"].getService(Components.interfaces.nsIAppStartup);
		appStartup.quit(appStartup.eForceQuit | appStartup.eRestart);
	},
	//Limpa e retorna proxy type
	shutdown: function() {
		mfull_actions.init();													//Inicializar
		try { toggleSidebar(); } catch (e) { }									//Fechar sidebar. Cuidado bug. Por isto o try!	
		mfull_lib.mainWindow.top.BrowserShutdown();
		mfull_lib.mainWindow.top.close();				
	},		
	gourl: function (url) { 
		switch (url) {
			case "downloadmfull":
					mfull_addonmanager.init();										//Inicializar bibioteca principal e base
					mfull_lib.AddonManager.getAddonByID(mfull_addonmanager.uid, function(addonparam) { 	
						mfull_lib.mainWindow.top.gBrowser.selectedTab = mfull_lib.mainWindow.top.gBrowser.loadOneTab(addonparam.homepageURL);										
					});
				break;
			case "downloadesr":
				mfull_lib.mainWindow.top.gBrowser.selectedTab = mfull_lib.mainWindow.top.gBrowser.loadOneTab("https://www.mozilla.org/en-US/firefox/organizations/all/");							
				break;
			case "donations":
				mfull_addonmanager.init();											//Inicializar bibioteca principal e base
				var strpaypal = encodeURIComponent("mFull:" + mfull_addonmanager.versionmk + ";FF:"+ mfull_addonmanager.versionff +  "-" + mfull_addonmanager.distribution + ";OS:" + mfull_addonmanager.systemSO + ";Lang:" + mfull_addonmanager.localeUserAgent + "/" + mfull_addonmanager.localeSO);
				mfull_lib.mainWindow.top.gBrowser.selectedTab = mfull_lib.mainWindow.top.gBrowser.loadOneTab("https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=XXSM5MUB2UK22&item_name=" + strpaypal);	
				break;
			default:
				break;
		}
		return true;
	},
	validateOptions: function (retorno,janela) {
		mfull_actions.init();													//Inicializar
		janela = typeof janela !== 'undefined' ? janela : false;											//Valor default delay inicial
		var retfunction = true;
		switch (retorno) {
			case "cancel":
				if (!mfull_lib.MyPrefBranch.getPrefType("config.unconfigured"))  {								//Primeira vez de tudo!
					mfull_dialogs.alert("mfull_config.firstconfigneed.title","mfull_config.firstconfigneed.body");			
					retfunction = false;
				} else if ( mfull_lib.MyPrefBranch.getBoolPref("config.unconfigured"))	{						//Resetado para defaults					
					mfull_dialogs.alert("mfull_config.firstconfigneed.title","mfull_config.firstconfigneed.body");
					retfunction = false;
				//} else if (!mfull_lib.MyPrefBranch.getBoolPref("config.islatestoptions")) {					//Novas opcoes disponiveis!
				//	mfull_dialogs.alert("mfull_config.firstconfigneed.title","mfull_config.firstconfigneed.body");
				//	retfunction = false;					
				} else {
					retfunction = true;
				}
				break;
			case "setalldefaults":
				mfull_addonmanager.cleanupbutton(! janela); //reiniciar browser ou da fechar?
				retfunction = true;
				break;
			case "disclosure":
				mfull_dialogs.showAbout();
				retfunction = true;
				break;		
			case "accept":
				mfull_lib.MyPrefBranch.setBoolPref("config.unconfigured", false);					//OK. Configurado!	
				mfull_lib.MyPrefBranch.setBoolPref("config.islatestoptions", true);				//OK. Configurado com ultimas opcoes!					
				retfunction = true;
				break;
			case "about:updates":
				openAboutDialog(); 
				retfunction = true;
				break;
			case "downloadesr":
			case "downloadmfull":
			case "donations":
				mfull_actions.gourl(retorno);
				retfunction = true;
				break;
		default:
				if (mfull_uteis.RegexpTest(retorno,'^about')) {
					mfull_lib.mainWindow.top.gBrowser.selectedTab = mfull_lib.mainWindow.top.gBrowser.loadOneTab(retorno);						
				}
				retfunction = true;
				break;
		}
		if (retfunction) 
			if (janela) janela.close();
		return retfunction;
	},
	showOptions: function(evnt, url) {
		mfull_actions.init();													//Inicializar
		if (!url) url = 'chrome://mfull/content/options/m_options.xul';
		var oldfullscreen = mfull_lib.current_fullscreen;
		mfull_aparencia.fullscreen(false);
		do {
			var retorno = mfull_dialogs.showDialog(url,false);											//window.arguments[0].out = cmd;
		} while (! mfull_actions.validateOptions(retorno));
		mfull_aparencia.fullscreen(oldfullscreen);
		mfull_dialogs.notify(" Firefox Info:", " mfull:\t" + mfull_addonmanager.versionmk + "\nFirefox:\t" + mfull_addonmanager.versionff + " (" + mfull_addonmanager.distribution + ")\nSysOp:\t" + mfull_addonmanager.systemSO +  "\nLang:\t" + mfull_addonmanager.localeUserAgent + "/" + mfull_addonmanager.localeSO,"full");	
	}
};

//Install, or uninstall
var mfull_addonmanager = {  
	isinit: false,						//Verifica se servico ativo
	uid : "{b555d844-5fad-45ed-a411-2535687f48a0}", 
	addon : null,						//Este Addon 
	versionmk : null, 					//Versao corrente do addon
	pendingOperations : 0,				//Operacoes pendentes?
	localeSO : Components.classes["@mozilla.org/intl/nslocaleservice;1"].getService(Components.interfaces.nsILocaleService).getSystemLocale().getCategory("NSILOCALE_CTYPE"), 
	systemSO : Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULAppInfo).OS,				//.OS : Returns "WINNT" on Windows,"Linux" on GNU/Linux. and "Darwin" on Mac OS X.
	versionff : Components.classes["@mozilla.org/xre/app-info;1"].getService(Components.interfaces.nsIXULAppInfo).version,			//.version : Retorn version ff, AppInfo.appBuildID : build, AppInfo.platformVersion: ?																																		
	distribution: null,		//app.update.channel
	localeUserAgent : null, //general.useragent.locale
	//Inicializa��o
	init: function () {
		if (mfull_addonmanager.isinit) return; mfull_addonmanager.isinit = true;
		mfull_lib.init();														//Inicializar bibioteca principal e base
		mfull_lib.AddonManager.getAddonByID(mfull_addonmanager.uid, function(addonparam) {
			mfull_addonmanager.addon = addonparam;																									//let extension = Application.extensions.get(mfull_addonmanager.uid);   
			mfull_addonmanager.versionmk = typeof mfull_addonmanager.addon.version !== 'undefined' ? mfull_addonmanager.addon.version : mfull_lib.Services.appinfo.version; //.name = Firefox
			mfull_addonmanager.systemSO = typeof mfull_addonmanager.systemSO !== 'undefined' ? mfull_addonmanager.systemSO : mfull_lib.Services.appinfo.OS; //Valor sem identificar
			mfull_addonmanager.pendingOperations = mfull_addonmanager.addon.pendingOperations;
			mfull_addonmanager.locationmk = mfull_addonmanager.addon.getResourceURI("").QueryInterface(Components.interfaces.nsIFileURL).file.path;
			try {
			  mfull_lib.AddonManager.addAddonListener(mfull_addonmanager);																//Auto adicionar listners
			} catch (ex) {}		  
		});
		//LocaleAgent ou Lingua de acesso
		mfull_addonmanager.localeUserAgent = mfull_lib.PrefBranch.getPrefType("general.useragent.locale") ? mfull_lib.PrefBranch.getCharPref("general.useragent.locale") : "-";
		mfull_addonmanager.distribution = mfull_lib.PrefBranch.getPrefType("app.update.channel") ? mfull_lib.PrefBranch.getCharPref("app.update.channel") : "unknown";
	}, 
	//Verifica��o online do codigo para execucao. Usar: if (mfull_addonmanager.myversionisup("3.9")) ...
	myversionisup: function (vercheck) {
		mfull_addonmanager.init();														//Inicializar bibioteca principal e base
		return (mfull_lib.VersionComparator.compare( mfull_addonmanager.versionff, vercheck ) >= 0 );
	},
	//Verificar se eh primeira vez ou um upgrade do mfull
	isFirstOrUpgrade: function () {
		mfull_addonmanager.init();														//Inicializar bibioteca principal e base
		mfull_lib.AddonManager.getAddonByID(mfull_addonmanager.uid, function(addonparam) { 	
			var e;		
			//Modo compatibilidade com versoes anteriores do firefox. Evitando este dialogo sem motivo quando administrador!
			if (mfull_lib.MyPrefBranch.prefHasUserValue('installedVersion')) {
				mfull_lib.MyPrefBranch.setBoolPref("config.firstrun", false);	//Primeira vez ok!				
			}
			//Primeira vez, nunca executado antes! Tambem caso prefs.js tenha sido removido!
			if (mfull_lib.MyPrefBranch.getBoolPref("config.firstrun")) { 
				mfull_lib.mainWindow.top.maximize();																		//Sempre maximiza
				mfull_addonmanager.cleanup(mfull_lib.strprefmfull, true);
				mfull_lib.MyPrefBranch.setBoolPref("config.firstrun", false);								//Primeira vez ok!
				mfull_lib.MyPrefBranch.setBoolPref("config.unconfigured", true);							//Totalmente desconfigurado!					
				// mfull_lib.mainWindow.top.gCustomizeMode.reset();											//Restaurar botoes ao lugar original!
				mfull_dialogs.alert("mfull_config.reset.title","mfull_config.reset.body");					//Obrigatorio aqui, depois do reset!
				mfull_actions.restart();
				return true;		
			}			
			//Executado e instalado, mas nao configurado ou resetado para as configuracoes para default
			if (mfull_lib.MyPrefBranch.getBoolPref("config.unconfigured") || (! mfull_lib.MyPrefBranch.prefHasUserValue("installedVersion"))) { 
				mfull_actions.gourl("downloadmfull");
				mfull_actions.showOptions();			
				openAboutDialog();
			} else { //Operacao cotidiana. J� estava instalado e configurado anteriormente				
				//Inicializar variaveis
				var installedVersion    = mfull_lib.MyPrefBranch.prefHasUserValue("installedVersion") == true ? mfull_lib.MyPrefBranch.getCharPref("installedVersion") : 0; 		//versao mfull anterior
				var installedAppVersion = mfull_lib.MyPrefBranch.prefHasUserValue("AppInfoVersion") == true   ? mfull_lib.MyPrefBranch.getCharPref("AppInfoVersion")   : 0;		//versao FF anterior
				/* Grande upgrade anual do mfull! */
				if (addonparam.version.replace(/^([0-9]+)[.]([0-9]+)[.].*$/gi,"$1") != installedVersion.replace(/^([0-9]+)[.]([0-9]+)[.].*$/gi,"$1"))  {  
					if (mfull_lib.MyPrefBranch.getBoolPref('laststate.fullscreen')) openAboutDialog(); //Intensionalmente procura upgrades do FF
				}
				/* Grande upgrade do FF! */
				if (mfull_addonmanager.versionff.replace(/^([0-9]+)[.]([0-9]+)[.].*$/gi,"$1") != installedAppVersion.replace(/^([0-9]+)[.]([0-9]+)[.].*$/gi,"$1"))  {  
					mfull_dialogs.notify(" mFull:", " mFull:\t" + mfull_addonmanager.versionmk + "\nFirefox:\t" + installedAppVersion + " >>> " + mfull_addonmanager.versionff + " (" + mfull_addonmanager.distribution +")\nSysOp:\t" + mfull_addonmanager.systemSO +  "\nLang:\t" + mfull_addonmanager.localeUserAgent + "/" + mfull_addonmanager.localeSO,"full");	
				}				
				/* Algum medio upgrade */
				if (addonparam.version.replace(/^([0-9]+)[.]([0-9]+)[.].*$/gi,"$1.$2") != installedVersion.replace(/^([0-9]+)[.]([0-9]+)[.].*$/gi,"$1.$2")) {  
					mfull_lib.MyPrefBranch.setBoolPref("config.islatestoptions", false);				//Tentar exibir opcoes na proxima vez!					
					mfull_dialogs.notify(" mFull:", " mFull:\t" + installedVersion + " >>> " + addonparam.version + "\nFirefox:\t" + mfull_addonmanager.versionff + " (" + mfull_addonmanager.distribution + ")\nSysOp:\t" + mfull_addonmanager.systemSO +  "\nLang:\t" + mfull_addonmanager.localeUserAgent + "/" + mfull_addonmanager.localeSO,"full");	
				} 
				/* Algum upgrade feito e ainda nao setado. Aproveitar se estiver em janela comum */
				if ((! mfull_lib.MyPrefBranch.getBoolPref('laststate.fullscreen')) && (! mfull_lib.MyPrefBranch.getBoolPref('config.islatestoptions'))) {	//Alteracoes feitas!
					mfull_actions.gourl("donations");
					mfull_actions.showOptions();
				}				
			}
			mfull_lib.MyPrefBranch.setCharPref("installedVersion", addonparam.version); 			//Atualizar versao addon
			mfull_lib.MyPrefBranch.setCharPref("AppInfoVersion", mfull_addonmanager.versionff);		//Atualizar versao FF
			return true;					
		});	
	},
	//Auto remover este complemento
	uninstall : function (uid) {
		mfull_addonmanager.init();														//Inicializar bibioteca principal e base
		uid = typeof uid !== 'undefined' ? uid : mfull_addonmanager.uid;						//uid do complemento
		mfull_lib.AddonManager.getAddonByID(uid, function(addonparam) {
			addonparam.uninstall();
		});	
	}, 
	//Auto desabilitar este complemento
	disable : function (uid) {
		mfull_addonmanager.init();														//Inicializar bibioteca principal e base
		uid = typeof uid !== 'undefined' ? uid : mfull_addonmanager.uid;				//uid do complemento
		mfull_lib.AddonManager.getAddonByID(uid, function(addonparam) {
			if (addonparam.isActive) addonparam.userDisabled = addonparam.isActive;
		});	
	}, 
	//Funcao que executa quando complemento desabilitado
	onDisabling: function(addonparam) {
		mfull_addonmanager.init();														//Inicializar bibioteca principal e base
		if (addonparam.id == mfull_addonmanager.uid) {
			dump("\nmFull Addon Disabling...\n");	
			mfull_actions.restart();	
		}	
	},
	//Funcao que executa quando desinstalado ou instalado
	onUninstalling: function(addonparam) {
		mfull_addonmanager.init();														//Inicializar bibioteca principal e base
		if (addonparam.id == mfull_addonmanager.uid) {
			dump("\nmFull Addon Uninstall...\n");	
			mfull_actions.restart();	
		}
	},
	//Funcao que executa quando opera��o cancelada de desinstala��o
	onOperationCancelled: function(addonparam) {
		mfull_addonmanager.init();														//Inicializar bibioteca principal e base
		if (addonparam.id == mfull_addonmanager.uid) {
			dump("\nmFull Addon Operation Cancelled...\n");	
			mfull_actions.restart();	
		}
	},
	cleanupbutton : function (restart) {
		mfull_addonmanager.init();														//Inicializar bibioteca principal e base
		restart = typeof restart !== 'undefined' ? restart : false;						//uid do complemento
		dump("\nmFull Addon Configs to Defaults...\n");	
		mfull_addonmanager.cleanup(mfull_lib.strprefmfull, true);
		mfull_lib.MyPrefBranch.setBoolPref("config.firstrun", false);											//Primeira vez ok!
		mfull_lib.MyPrefBranch.setBoolPref("config.unconfigured", true)										//Totalmente desconfigurado!
		mfull_lib.PrefBranch.clearUserPref("browser.fullscreen.autohide");														//Limpar preferencia de usuario
		// mfull_lib.mainWindow.top.gCustomizeMode.reset();																		//Restaurar botoes ao lugar original!
		mfull_dialogs.alert("mfull_config.reset.title","mfull_config.reset.body");		
		if (restart) {
			mfull_actions.restart();
		} else {
			mfull_aparencia.shutdown();
		}
	},
	//Limpa todas as preferencias. https://developer.mozilla.org/en-US/docs/Code_snippets/Preferences
	cleanup : function (addonstr,onlyuserpref) {
		mfull_addonmanager.init();														//Inicializar bibioteca principal e base
	   addonstr = typeof addonstr !== 'undefined' ? addonstr : mfull_lib.strprefmfull;//extension.mfull.
	   onlyuserpref = typeof onlyuserpref !== 'undefined' ? onlyuserpref : false;						//uid do complemento
	   var arr = mfull_lib.MyPrefBranch.getChildList("", {});
	   for (var prop in arr) {
	  	if (arr.hasOwnProperty(prop)) { 
			if (onlyuserpref) {
				mfull_lib.PrefBranch.deleteBranch(addonstr + arr[prop]);  //Limpar todas preferencias, removendo tudo
			} else {
				mfull_lib.PrefBranch.clearUserPref(addonstr + arr[prop]); //Limpar dados do usu�rio, colocando valores default ou apagando caso inexista
			}
	  	}
	  }	  	  
	}	
}

